from time import sleep
from network import WLAN,STA_IF
from machine import reset
import urequests as rq
import json

ssid = "Laboratorium-IoT" #"iot_test"
password = "XaraZuum1223" #"RPi_pico"

def wifi_connect():
    wlan = WLAN(STA_IF)
    wlan.active(True)
    wlan.connect(ssid,password)
    while wlan.isconnected() == False:
        print("Connection to " + ssid)
        sleep(1)
    print(wlan.ifconfig())
    print(f'Connected to {ssid} network, IP {wlan.ifconfig()[0]}')

try:
    wifi_connect()
except KeyboardInterrupt:
    reset()
    
print("\n\n2. Querying the current GMT+0 time:")
date_time = rq.get("http://time.jsontest.com")
print(date_time.json())
today = 'Today is ' + date_time.json().get('date')
print(today)
print('What time is right now? ' + date_time.json().get('time'))
